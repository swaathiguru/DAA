def txtload():
    #The input file is opened with the file pointer fp
    with open("input1.txt", 'r') as fp:
        #Gets the total number of lines in the file
        x = len(fp.readlines())
        fp.seek(0)  #Resets the file pointer to 0
        lines=fp.readlines()    #Entire data in the file is loaded into lines variable

        data = []
        for val in lines:   #Each line terminator '\n' is being removed and appended into data
            data.append(val.replace("\n", ""))

        dataInp(data,x) #Processed data is forwarded to the dataInp function

def dataInp(data,x):
    #For loop iterates with a gap of 2, so that each sequence is considered along with the data array and length
    for i in range(0, x, 2):
        n = int(data[i])
        p = data[i+1][1:-1] #[ and ] are being removed from both ends
        p = list(map(int, p.split(',')))    #Each array is loaded into p which is split by ','
        print("The max revenue is " + str(cut_rod(p,n)))    #Each case is passed on to cut_rod()

def cut_rod(p,n):
    if(n == 0):
        return n
    q = float('-INF')
    for i in range(1, n+1):
        q = max(q, p[i-1] + cut_rod(p, n-i))
    return q

def main():
    #The main function calls for txtload(), which loads the data from the tet file
    txtload()

main()