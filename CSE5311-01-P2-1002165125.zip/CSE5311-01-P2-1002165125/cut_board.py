import ast

def totCost(w, h, cuts):
    #cuts has been appended with extra 2 values, that has 
    # the 0,0 and the overall width and height is also appeneded
    cuts = [[0, 0]] + cuts + [[w, h]]

    #this disctionary is used to store the values once calculated 
    # and then can be reused if needed in the future calls
    dp_dict = {}

    def cost_of_cut(i, j):
        #This function finds out which new board the cut is about to be made with the help of cuts array and finds the width, height of the
        # board and calculates the cost by multiplying them along with 2
        w = cuts[j][0] - cuts[i][0]
        h = cuts[j][1] - cuts[i][1]

        cut_cost = 2 * w * h

        return cut_cost

    def cut_board(i, j):
        #When the same cut dimensions are already present in the dictionary, 
        # the pre-calculated value is used instead of calculating them again
        if ((i, j) in dp_dict):
            return dp_dict[(i, j)]

        #On other case when the dimensions are matching the same, 
        # the calculated value is supposed to be 0, which is being returned accordingly.
        if (i + 1 == j):
            return 0, []

        mv = float('inf')

        order = []

        for k in range(i + 1, j):
            cost, cuts_order = cut_board(i, k)  #For every cut, the iteration is processed
            cost = cost + cut_board(k, j)[0] + cost_of_cut(i, j) #The calculated cost is added with the remaining cuts

            if cost < mv:   #Comparing with the minimum value, to check if it is minimum and then updated accordingly
                mv = cost
                order = [cuts[k]] + cuts_order

        dp_dict[(i, j)] = mv, order #Following update is done in the dictionary too

        return mv, order

    min_cost, optimal_order = cut_board(0, len(cuts) - 1) #The whole process happens throughout the cuts value present

    return min_cost, optimal_order

with open('input2.txt', 'r') as fp:
    #Input data file is opened via filepointer fp and all the 
    # lines are stored in the variable lines
    lines = fp.readlines()

for i in range(0, len(lines), 2):
    #For every iteration with a gap of 2, data is fed in to respective variables along with the arrays of cuts
    w, h = map(int, lines[i].strip().split())
    cuts = ast.literal_eval(lines[i + 1])

    #Required data is passed on to the function and the final output is retreived
    min_cost, optimal_order = totCost(w, h, cuts)

    print(f"The minimum total cost is {min_cost}. The optimal order of the cuts is {optimal_order}")