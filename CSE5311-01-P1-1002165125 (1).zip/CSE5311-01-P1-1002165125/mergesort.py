import time
import numpy as np

def load(a): 
    # this function loads the data into the input file
    arr =  np.loadtxt('arr'+str(a)+'.txt', delimiter=' ')
    return arr

def row_sum(x,col): 
    # this function is to calculate the sum and append it in a new column
    x_new = []
    for A in x:
        rowSum = 0
        n = len(A)
        for j in range (0,n):
            rowSum = rowSum + A[j]
        A = np.append(A, int(rowSum))
        x_new = np.append(x_new, A)
    x_final = x_new.reshape(col,4)

    return x_final

def merge(A, p, q, r):
    L = A[p:q+1].copy() 
    #copying the elements to the left subarray
    R = A[q+1:r+1].copy() 
    # copying the elements to the right subarray
 
    i = 0     
    # initial index of the left subarray
    j = 0   
    # initial index of the right subarray
    k = p    
    # initial index of the merged subarray

    n1 = len(L)
    # n1 holds the length of the left subarray
    n2 = len(R)
    #n2 holds the length of the right subarray
 
    while i < n1 and j < n2:
        if L[i][3] <= R[j][3]:
            A[k] = L[i].copy()
            i += 1
        else:
            A[k] = R[j].copy()
            j += 1
        k += 1
 
    # Copying the remaining elements in L[]
    while i < n1:
        A[k] = L[i].copy()
        i += 1
        k += 1
 
    # Copying the remaining elements in R[]
    while j < n2:
        A[k] = R[j].copy()
        j += 1
        k += 1

def merge_sort(A,p,r): 
    # this function performs the merge sorting 
    if p < r :
        q = (p + (r-1)) // 2
        merge_sort(A,p,q) #recursively calling the function holding till the middle element
        merge_sort(A,q+1,r) #recursively calling the function holding from the middle element to the last
        merge(A,p,q,r) #recursively calling the function merge including all the elements

def mergeProg(matr, num): 
    matr = row_sum(matr, num)
    colA = [row[3] for row in matr]
    r = len(colA)
    st = time.time() #start time
    merge_sort(matr,0,r-1)
    end = time.time() #end time
    sort_time = (end - st)*10**3 # generating sorting time for the algorithm
    print(num,'sets -',sort_time,'ms')
    np.savetxt('MR_O/arrMR_O_'+str(num)+'.txt',matr,fmt='%.0f')
    with open('MR_O/arrMR_O_'+str(num)+'.txt', 'a') as file: # generating the output file
        file.write('\n')
        file.write(str(sort_time)) # writing the time taken in the output file
    
matr_20 = np.loadtxt('arr20.txt', delimiter=' ')
mergeProg(matr_20, 20) # calling the function to perform the merge sort for the matrix array of 20 elements 
matr_100 = np.loadtxt('arr100.txt', delimiter=' ')
mergeProg(matr_100, 100) # calling the function to perform the merge sort for the matrix array of 100 elements 
matr_2000 = np.loadtxt('arr2000.txt', delimiter=' ')
mergeProg(matr_2000, 2000) # calling the function to perform the merge sort for the matrix array of 2000 elements
matr_6000 = np.loadtxt('arr6000.txt', delimiter=' ')
mergeProg(matr_6000, 6000) # calling the function to perform the merge sort for the matrix array of 6000 elements
