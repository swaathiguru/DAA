import time 
import numpy as np
import copy

def matr(a): 
    # generating random integers and storing them as in the input files
    arr = np.random.randint(low=0, high=99, size=(a,3))
    with open('arr'+str(a)+'.txt','wb') as f:
        np.savetxt(f, arr, fmt='%.0f') 
        #input file is created

def row_sum(x,col): # this function generates the sum of the elements in the given array
    x_new = []
    for A in x:
        rowSum = 0
        n = len(A)
        # n holds the length of the array
        for j in range (0,n):
            rowSum = rowSum + A[j] 
            # computing the sum of the elements in the array
        A = np.append(A, int(rowSum)) 
        x_new = np.append(x_new, A)
    x_final = x_new.reshape(col,4) 
    # the fourth element in the array holds the sum of the preceding elements in the array

    return x_final

def insertion_sort(matr, A): 
    # function to perform the insertion sort
    for j in range(1, len(A)):
        row_data = copy.deepcopy(matr[j])
        key = A[j]
        i = j - 1 
        while i >= 0 and key < A[i]:
            A[i + 1] = A[i] 
            matr[i+1] = matr[i] 
            #elements lesser than the key are moved to the left and the larger elements are on the right
            i -= 1
        A[i + 1] = key
        matr[i+1] = row_data

def insertProg(matr, num): 
    matr = row_sum(matr, num)
    colA = [row[3] for row in matr]
    st = time.time() #start time
    insertion_sort(matr,colA)
    end = time.time() #end time
    sort_time = (end - st)*10**3 # calculating the sorting time 
    print(num,'sets -',sort_time,'ms')
    np.savetxt('IS_O/arrIS_O_'+str(num)+'.txt',matr,fmt='%.0f') 
    with open('IS_O/arrIS_O_'+str(num)+'.txt', 'a') as file:
        file.write('\n')
        file.write(str(sort_time)) 
        # generating the running time in the output file

matr(20) 
matr(100)
matr(2000)
matr(6000)

matr_20 = np.loadtxt('arr20.txt', delimiter=' ')
insertProg(matr_20, 20) 
# calling the function to perform the insertion sort for the matrix array of 20 elements 
matr_100 = np.loadtxt('arr100.txt', delimiter=' ')
insertProg(matr_100, 100) 
# calling the function to perform the insertion sort for the matrix array of 100 elements 
matr_2000 = np.loadtxt('arr2000.txt', delimiter=' ')
insertProg(matr_2000, 2000) 
# calling the function to perform the insertion sort for the matrix array of 2000 elements 
matr_6000 = np.loadtxt('arr6000.txt', delimiter=' ')
insertProg(matr_6000, 6000) 
# calling the function to perform the insertion sort for the matrix array of 6000 elements 