import time
import numpy as np

def load(a):
    arr =  np.loadtxt('arr'+str(a)+'.txt', delimiter=' ') 
    #loading the input text file
    return arr

def row_sum(x,col): 
    # generating the sum of the row in the array
    x_new = []
    for A in x:
        rowSum = 0
        n = len(A)
        for j in range (0,n):
            rowSum = rowSum + A[j] 
        A = np.append(A, int(rowSum))
        x_new = np.append(x_new, A) 
        # appending the value of the sum in the element 
    x_final = x_new.reshape(col,4)

    return x_final

def partn(A, p, r):
 
    # rightmost element in the array is chosen as the pivot element as x
    x = A[r][3]
 
    # we choose a pointer i for the greater element
    i = p - 1
 
    # traversing through all elements
    # comparing each element with x
    for j in range(p, r):
        if A[j][3] <= x:
 
            # If element smaller than x is found
            # swapping it with the greater element pointed by i
            i = i + 1
 
            # Swapping element at i with element 
            temp = A[i].copy()
            A[i] = A[j].copy()
            A[j] = temp.copy()
 
    # Swapping the pivot element with the greater element which is specified by i
    temp = A[i+1].copy()
    A[i+1] = A[r].copy()
    A[r] = temp.copy()
 
    return i + 1
 

 
def quick_sort(A, p, r):
    # declaring a function to perform the function of quicksort
 
    if r > p:
 
        # Find the pivot element such that
        # element smaller than x which is the pivot element are on the left
        # element greater than x which is the pivot element are on the right
        q = partn(A, p, r)
 
        # Recursive call on the left of x
        quick_sort(A, p, q - 1)
 
        # Recursive call on the right of x
        quick_sort(A, q + 1, r)
 
def quickProg(matr, num):
    matr = row_sum(matr, num)
    colA = [row[3] for row in matr]
    r = len(colA)
    st = time.time() # start time
    quick_sort(matr,0,r-1)
    end = time.time() # end time
    sort_time = (end - st)*10**3 #computing the sorting time
    print(num,'sets -',sort_time,'ms')
    np.savetxt('QK_O/arrQK_O_'+str(num)+'.txt',matr,fmt='%.0f')
    with open('QK_O/arrQK_O_'+str(num)+'.txt', 'a') as file: #generating the output file
        file.write('\n')
        file.write(str(sort_time)) #generating the running time in the output file
 
matr_20 = np.loadtxt('arr20.txt', delimiter=' ')
quickProg(matr_20, 20) 
# calling the function to perform the quick sort for the matrix array of 20 elements
matr_100 = np.loadtxt('arr100.txt', delimiter=' ')
quickProg(matr_100, 100) 
# calling the function to perform the quick sort for the matrix array of 100 elements
matr_2000 = np.loadtxt('arr2000.txt', delimiter=' ')
quickProg(matr_2000, 2000) 
# calling the function to perform the quick sort for the matrix array of 2000 elements
matr_6000 = np.loadtxt('arr6000.txt', delimiter=' ')
quickProg(matr_6000, 6000) 
# calling the function to perform the quick sort for the matrix array of 6000 elements